<html>
<head>
<title>::Leave Management::</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php
echo "<div class = 'heading'>";
echo "<h1>Leave Management System</h1>";
include 'navi.php';
echo "<center>";
echo "<h4> Page Under Construction ! </h4>";
echo "</center>";
echo "</div>";
?>
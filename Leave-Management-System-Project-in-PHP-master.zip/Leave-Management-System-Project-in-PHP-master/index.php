<html>
<head>
<title>::Leave Management::</title>
<link rel="stylesheet" href="style.css">
<style>
footer {
    width:100%;
    background-color : #cecece;
	position: fixed;
    bottom: 0;
	font-family: "Segoe UI Light","Segoe WPC","Segoe UI",
              Helvetica, Arial, "Arial Unicode MS", Sans-Serif;
	font-size: 17px;
	font-style: normal;
	font-variant: normal;
	font-weight: 500;
	height : 30px;
	text-align: center;
	box-shadow: 0px 1px 50px #5E5E5E;
}
</style>
</head>
<body>
<center>
<div class="heading"><h1>Leave Management System</h1></div>
<?php include 'navi.php';?>
<div class="heading"><h2>Welcome !</h2>
<p>A Small Leave Management System, fully created in php</p>
<p> A Project By projectworlds </p>
<footer>&copy; 2018, Projectworlds.in</footer>
</center>
</div>
</body>
</html>